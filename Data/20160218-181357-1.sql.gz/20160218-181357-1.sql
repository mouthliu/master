-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : mjmf
-- 
-- Part : #1
-- Date : 2016-02-18 18:13:57
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

